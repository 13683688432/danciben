package com.example.danciben;

import java.util.UUID;

public class GUID {
    public static String getGUID(){
        UUID uuid = UUID.randomUUID();   //创建GUID对象
        String a= uuid.toString();   //得到对象产生的ID
        a = a.toUpperCase();   //转化为大写
        a = a.replace("-","");//替换掉“-”
        return a;
    }
}
