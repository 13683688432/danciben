package com.example.danciben;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AlertDialogLayout;
import androidx.arch.core.executor.TaskExecutor;

import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.zip.Inflater;

public class MainActivity extends AppCompatActivity   implements View.OnClickListener{
    private MyDatabaseHelper dbhelper;    //创建数据库对象
    ArrayList DATA = new ArrayList();    //这里的DATA用于在各种事件中承载左侧List中的单词
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final int orientation = this.getResources().getConfiguration().orientation;
        dbhelper = new MyDatabaseHelper(this,"WORDS.db",1);   //这里我省略了factory  前面的构造方法里就省略了
        dbhelper.getWritableDatabase();   //这里成功创建   查阅资料得知为何在命令行里输入su不能切换为超级管理员  然后我就重建了一个模拟器
//        final View view =  LayoutInflater.from(MainActivity.this).inflate(R.layout.fragment_left,null);  //查询时在左侧Listview显示查询结果的word

        final SQLiteDatabase db = dbhelper.getWritableDatabase();  //得到该数据库
        //这里是初始化  一进来就显示所有的单词
        final ListView listview = (ListView)findViewById(R.id.LS);
        shuaxin();
//        Cursor cursor = db.query("WORDS",new String[]{
//                "word","fanyi","liju"},null,null,null,null,null);
//        final ArrayList data = new ArrayList();
//        if(cursor.moveToFirst()){
//            do{
//                String word = cursor.getString(cursor.getColumnIndex("word"));
//                String fanyi = cursor.getString(cursor.getColumnIndex("fanyi"));
//                String liju = cursor.getString(cursor.getColumnIndex("liju"));
//                Log.d("MainActicity","单词是"+word);
//                Log.d("MainActicity","翻译是"+fanyi);
//                Log.d("MainActicity","例句是"+liju);       //这里是LOG输出检查  可以忽略
//                data.add(word);
//            }while (cursor.moveToNext());
//            cursor.close();
//            ArrayAdapter<String> adapter = new ArrayAdapter<String>(
//                    MainActivity.this,android.R.layout.simple_list_item_1,data);
//            listview.setAdapter(adapter);
//        }


        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ////////////////////////////////////////////////////判断横屏
                if (orientation == Configuration.ORIENTATION_LANDSCAPE) {      //这里判断是否为横屏   横屏则输出  竖屏则不做操作
                    TextView tx1 = (TextView) findViewById(R.id.tx1);
                TextView tx2 = (TextView) findViewById(R.id.tx2);
                TextView tx3 = (TextView) findViewById(R.id.tx3);


                Cursor cursor = db.query("WORDS", new String[]{       //这是复制的上面的载入界面的代码  主要是为了更新data
                        "word", "fanyi", "liju"}, null, null, null, null, null);
                ArrayList data = new ArrayList();
                if (cursor.moveToFirst()) {
                    do {
                        String word = cursor.getString(cursor.getColumnIndex("word"));
                        String fanyi = cursor.getString(cursor.getColumnIndex("fanyi"));
                        String liju = cursor.getString(cursor.getColumnIndex("liju"));
                        Log.d("MainActicity", "单词是" + word);
                        Log.d("MainActicity", "翻译是" + fanyi);
                        Log.d("MainActicity", "例句是" + liju);       //这里是LOG输出检查  可以忽略
                        data.add(word);
                    } while (cursor.moveToNext());
                    cursor.close();
                }


                //现在的问题是  模糊查询的结果点开后会因为数据库的位置和data的位置不一致而产生错误   而后经过设置了一个DATA用于承载listview中的单词来实现各种事件中listview的同步
                data = DATA;      //这里的DATA用于在各种事件中承载左侧List中的单词
                String A = data.get(position) + "";
                String B = "";
                Cursor XS = db.query("WORDS", new String[]{     //这次搜索是搜索的被点击的单词  并在right中进行显示细节
                        "word", "fanyi", "liju"}, "word like ?", new String[]{A}, null, null, null);   //找到这个单词  条件为 word为A
                if (XS.moveToFirst()) {
                    do {
                        tx1.setText(XS.getString(XS.getColumnIndex("word")) + "");
                        tx2.setText(XS.getString(XS.getColumnIndex("fanyi")) + "");
                        tx3.setText(XS.getString(XS.getColumnIndex("liju")) + "");
                        //下面这条用来测试点击事件的
//                        Toast.makeText(MainActivity.this, A, Toast.LENGTH_SHORT).show();
                    } while (XS.moveToNext());
                }
                XS.close();
            }
                else{            //这里是后续增加的竖屏状态的弹出对话框以及详细输出
                    AlertDialog.Builder ZJ = new AlertDialog.Builder(MainActivity.this);
                    View view2 =  LayoutInflater.from(MainActivity.this).inflate(R.layout.fragment_insert,null);
                    TextView xs1 = view2.findViewById(R.id.zj1);
                    TextView xs2 = view2.findViewById(R.id.zj2);
                    TextView xs3 = view2.findViewById(R.id.zj3);   //这里复用fragment  利用插入的界面来输出单词详细信息
                    String A = DATA.get(position) + "";
                    String B = "";
                    Cursor XS = db.query("WORDS", new String[]{     //这次搜索是搜索的被点击的单词  并在right中进行显示细节
                            "word", "fanyi", "liju"}, "word like ?", new String[]{A}, null, null, null);   //找到这个单词  条件为 word为A
                    if (XS.moveToFirst()) {
                        do {
                            xs1.setText(XS.getString(XS.getColumnIndex("word")) + "");
                            xs2.setText(XS.getString(XS.getColumnIndex("fanyi")) + "");
                            xs3.setText(XS.getString(XS.getColumnIndex("liju")) + "");
                            //下面这条用来测试点击事件的
//                        Toast.makeText(MainActivity.this, A, Toast.LENGTH_SHORT).show();
                        } while (XS.moveToNext());
                    }
                    XS.close();
                    ZJ.setView(view2).show();
                }
            }
        });
    }
    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.ZJ:      //增加单词
                AlertDialog.Builder ZJ = new AlertDialog.Builder(MainActivity.this);
               View view =  LayoutInflater.from(MainActivity.this).inflate(R.layout.fragment_insert,null);
                final EditText zj1 = (EditText) view.findViewById(R.id.zj1);
                final EditText zj2 = (EditText) view.findViewById(R.id.zj2);
                final EditText zj3 = (EditText)  view.findViewById(R.id.zj3);
                ZJ.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
               //这里写新建单词确定后的操作
                SQLiteDatabase db = dbhelper.getWritableDatabase();
                        ContentValues values = new ContentValues();
                        //接下是插入数据的代码
                    values.put("word",zj1.getText().toString()+"");
                    values.put("fanyi",zj2.getText().toString()+"");
                    values.put("liju",zj3.getText().toString()+"");
                    db.insert("WORDS",null,values);
                    values.clear();
                        Button ZJ = (Button) findViewById(R.id.ZJ);
                        Toast.makeText(MainActivity.this,"单词添加成功！",Toast.LENGTH_SHORT).show();
                        shuaxin();      //这里修改了 我将刷新设置为了一个方法进行调用
                    }
                }).setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                //这里是取消  不需要任何代码
                    }
                });

                ZJ.setTitle("新建单词").setView(view).show();

                break;
            case R.id.CX:      //查询单词
                AlertDialog.Builder CX = new AlertDialog.Builder(MainActivity.this);
                View view2 =  LayoutInflater.from(MainActivity.this).inflate(R.layout.fragment_query,null);
                View view6 =  LayoutInflater.from(MainActivity.this).inflate(R.layout.fragment_left,null);  //查询时在左侧Listview显示查询结果的word
                final EditText cx = (EditText) view2.findViewById(R.id.cx);
                CX.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //这里写查询单词确定后的操作
                        SQLiteDatabase db = dbhelper.getWritableDatabase();
                        String contain  = "%"+cx.getText().toString()+"%";   //让contain承载sql语句  实现模糊查找 （找到含有目标字段的单词）
                        Cursor cursor = db.query("WORDS",new String[]{
                                "word","fanyi","liju"},"word like ?",new String[]{contain},null,null,null);
                        ArrayList data = new ArrayList();
                        if(cursor.moveToFirst()){
                            do{
                                String word = cursor.getString(cursor.getColumnIndex("word"));
                                String fanyi = cursor.getString(cursor.getColumnIndex("fanyi"));
                                String liju = cursor.getString(cursor.getColumnIndex("liju"));
                                Log.d("MainActicity","单词是"+word);
                                Log.d("MainActicity","翻译是"+fanyi);
                                Log.d("MainActicity","例句是"+liju);       //这里是LOG输出检查  可以忽略
                                data.add(word);
                            }while (cursor.moveToNext());
                            DATA= data;        //这里的DATA用于在各种事件中承载左侧List中的单词
                            cursor.close();
                        }
                        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                                MainActivity.this,android.R.layout.simple_list_item_1,data);
                        ListView listview = (ListView)findViewById(R.id.LS);
                        listview.setAdapter(adapter);




                    }
                }).setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //这里是取消  不需要任何代码
                    }
                });
                CX.setTitle("查询单词").setView(view2).show();
                break;
            case R.id.XG:      //修改单词
                AlertDialog.Builder XG = new AlertDialog.Builder(MainActivity.this);
                View view3 =  LayoutInflater.from(MainActivity.this).inflate(R.layout.fragment_modify,null);
                final EditText xg1 = (EditText) view3.findViewById(R.id.xg1);
                final EditText xg2 = (EditText) view3.findViewById(R.id.xg2);
                final EditText xg3 = (EditText) view3.findViewById(R.id.xg3);
                final TextView tx1 = findViewById(R.id.tx1);
                //右边fragment 的单词框
                XG.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //这里写修改单词确定后的操作
                        SQLiteDatabase db = dbhelper.getWritableDatabase();
                        ContentValues values = new ContentValues();
                        //接下是插入数据的代码
                        values.put("word",xg1.getText().toString()+"");
                        values.put("fanyi",xg2.getText().toString()+"");
                        values.put("liju",xg3.getText().toString()+"");
                        db.update("WORDS",values,"word like ?",new String[] {(tx1.getText().toString()+"")});//这里把右边单词框内的单词修改掉
                        values.clear();
                        Toast.makeText(MainActivity.this,"单词修改成功！",Toast.LENGTH_SHORT).show();
                        shuaxin();
                    }
                }).setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //这里是取消  不需要任何代码
                    }
                });
                XG.setTitle("修改单词").setView(view3).show();
                break;
            case R.id.SC:      //删除单词
                AlertDialog.Builder SC = new AlertDialog.Builder(MainActivity.this);
                SC.setTitle("是否确定删除？");
                SC.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //这里写删除单词确定后的操作
                        SQLiteDatabase db = dbhelper.getWritableDatabase();
                        //接下是删除数据的代码
                        TextView tx1 = (TextView)findViewById(R.id.tx1) ;
                        db.delete("WORDS","word like ?",new String[] {(tx1.getText().toString()+"")});//这里把右边单词框内的单词修改掉
                        Toast.makeText(MainActivity.this,"单词删除成功！",Toast.LENGTH_SHORT).show();
                        shuaxin();


                    }
                }).setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //这里是取消  不需要任何代码
                    }
                });
                SC.show();
                break;
            case R.id.SX:      //这里是刷新  其实就是查询条件为空
               shuaxin();
                break;
                
            case R.id.BZ:
                AlertDialog.Builder BZ = new AlertDialog.Builder(MainActivity.this);
                BZ.setTitle("帮助");
                BZ.setMessage("这里是帮助");
                BZ.show();
                break;
        }
    }
    private void shuaxin(){   //这里是后来修改的  我将shuaxin直接独立出来写成方法   大大减少了代码量
        View view7 =  LayoutInflater.from(MainActivity.this).inflate(R.layout.fragment_left,null);  //查询时在左侧Listview显示查询结果的word
        SQLiteDatabase db = dbhelper.getWritableDatabase();
        Cursor cursor = db.query("WORDS",new String[]{
                "word","fanyi","liju"},null,null,null,null,null);
        ArrayList data = new ArrayList();
        if(cursor.moveToFirst()){
            do{
                String word = cursor.getString(cursor.getColumnIndex("word"));
                String fanyi = cursor.getString(cursor.getColumnIndex("fanyi"));
                String liju = cursor.getString(cursor.getColumnIndex("liju"));
                Log.d("MainActicity","单词是"+word);
                Log.d("MainActicity","翻译是"+fanyi);
                Log.d("MainActicity","例句是"+liju);       //这里是LOG输出检查  可以忽略
                data.add(word);
            }while (cursor.moveToNext());
            DATA = data;    //这里的DATA用于在各种事件中承载左侧List中的单词
            cursor.close();
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                MainActivity.this,android.R.layout.simple_list_item_1,data);
        ListView listview = (ListView)findViewById(R.id.LS);
        listview.setAdapter(adapter);
    }

}
