package com.example.danciben;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class MyDatabaseHelper extends SQLiteOpenHelper {
    private Context mContext;
    final String CREATE_TABLE_SQL = "create table WORDS(_id integer primary key autoincrement , word , fanyi , liju)";
    public MyDatabaseHelper(@Nullable Context context, @Nullable String name, int version) {
        super(context, name,null, version);
        mContext = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_SQL);

        Toast.makeText(mContext,"创建数据库成功！",Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        System.out.println("------------------onUpdate Called------------------"+ oldVersion + "------->" + newVersion);
    }
    public void insertData(SQLiteDatabase db, String word, String fanyi,String liju) {
            db.execSQL("insert into WORDS values(null , ?, ?, ? )", new String[]{word,fanyi,liju});
    }

}
